
import React from 'react';
import { Calendar, User, Hammer, CheckCircle2, ShieldCheck, Heart, Award } from 'lucide-react';
import { COMPANY_INFO } from '../constants';

const Portfolio: React.FC = () => {
  return (
    <section id="portfolio" className="py-24 px-4 overflow-hidden bg-yellow-100/30">
      <div className="max-w-5xl mx-auto">
        <div className="bg-amber-900 rounded-[4rem] p-10 md:p-20 text-white relative overflow-hidden shadow-2xl">
          {/* Abstract Decorations */}
          <div className="absolute top-0 right-0 w-96 h-96 bg-yellow-400/20 rounded-full blur-[100px] -mr-48 -mt-48"></div>
          <div className="absolute bottom-0 left-0 w-80 h-80 bg-amber-400/10 rounded-full blur-[80px] -ml-40 -mb-40"></div>

          <div className="relative z-10 text-center max-w-3xl mx-auto">
            <div className="space-y-12">
              <div className="space-y-6">
                <div className="flex justify-center mb-6">
                  <span className="inline-block px-6 py-2 bg-yellow-400/20 text-yellow-400 rounded-full text-sm font-bold uppercase tracking-[0.2em] border border-yellow-400/30">
                    Established 2025
                  </span>
                </div>
                <h2 className="text-5xl md:text-7xl font-fredoka font-bold text-yellow-400 leading-tight">Portofolio <br/>Piscok Bohay</h2>
                <p className="text-amber-100/90 text-xl leading-relaxed font-medium">
                  Dedikasi kami adalah menghadirkan Piscok dengan kualitas premium. Setiap gigitan adalah perpaduan kulit lumpia yang super renyah dan isian coklat yang benar-benar lumer. Diproses secara higienis oleh tim profesional.
                </p>
              </div>

              <div className="grid sm:grid-cols-2 gap-8 text-left">
                <div className="bg-white/10 backdrop-blur-xl p-8 rounded-[2.5rem] border border-white/10 hover:bg-white/15 transition-all group">
                  <div className="bg-yellow-400/20 w-16 h-16 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                    <Calendar className="text-yellow-400" size={32} />
                  </div>
                  <div className="text-xs font-bold text-yellow-400/70 uppercase tracking-widest mb-1">Berdiri Sejak</div>
                  <div className="text-3xl font-bold">{COMPANY_INFO.since}</div>
                </div>
                
                <div className="bg-white/10 backdrop-blur-xl p-8 rounded-[2.5rem] border border-white/10 hover:bg-white/15 transition-all group">
                  <div className="bg-yellow-400/20 w-16 h-16 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                    <User className="text-yellow-400" size={32} />
                  </div>
                  <div className="text-xs font-bold text-yellow-400/70 uppercase tracking-widest mb-1">Owner</div>
                  <div className="text-3xl font-bold">{COMPANY_INFO.owner}</div>
                </div>

                <div className="bg-white/10 backdrop-blur-xl p-10 rounded-[2.5rem] border border-white/10 hover:bg-white/15 transition-all group sm:col-span-2">
                  <div className="flex flex-col sm:flex-row items-center sm:space-x-8 text-center sm:text-left">
                    <div className="bg-yellow-400/20 w-20 h-20 rounded-3xl flex items-center justify-center mb-6 sm:mb-0 shrink-0">
                      <Hammer className="text-yellow-400" size={40} />
                    </div>
                    <div>
                      <div className="text-xs font-bold text-yellow-400/70 uppercase tracking-widest mb-2">Diproduksi Oleh</div>
                      <div className="text-4xl font-bold leading-tight">{COMPANY_INFO.producer}</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-20 pt-12 border-t border-white/10 flex flex-wrap justify-center gap-6">
              {[
                { label: 'Bahan Premium', icon: Award },
                { label: 'Tanpa Pengawet', icon: ShieldCheck },
                { label: 'Selalu Fresh', icon: Heart },
                { label: 'Higienis', icon: CheckCircle2 }
              ].map((item, idx) => (
                <div key={idx} className="flex items-center space-x-3 text-yellow-400 font-bold bg-white/5 px-6 py-4 rounded-3xl border border-white/5 hover:bg-white/10 transition-colors">
                  <item.icon size={24} className="text-yellow-500" />
                  <span className="text-lg">{item.label}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Portfolio;
