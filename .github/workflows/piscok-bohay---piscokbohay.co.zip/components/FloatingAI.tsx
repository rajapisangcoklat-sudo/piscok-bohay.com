
import React from 'react';
import { Bot, Sparkles } from 'lucide-react';

const FloatingAI: React.FC = () => {
  return (
    <div className="fixed bottom-8 left-8 z-[90] group">
      <a 
        href="https://form.jotform.com/agent/019b29f4d09d7d2b89e889c7f7bc65d4547b" 
        target="_blank" 
        rel="noopener noreferrer"
        className="relative block"
      >
        {/* Animated Background Ring */}
        <div className="absolute -inset-4 bg-yellow-400/20 rounded-full animate-pulse opacity-0 group-hover:opacity-100 transition-opacity"></div>
        
        {/* Main Button */}
        <div className="relative bg-gradient-to-br from-yellow-400 to-amber-600 text-white p-5 rounded-full shadow-2xl shadow-yellow-200/50 flex items-center justify-center transform group-hover:scale-110 group-hover:rotate-12 transition-all duration-300 border-4 border-white">
          <Bot size={32} />
          <div className="absolute -top-1 -right-1 bg-white text-amber-600 rounded-full p-1 shadow-sm">
            <Sparkles size={12} fill="currentColor" />
          </div>
          
          {/* Tooltip Label */}
          <span className="absolute left-full ml-4 bg-amber-900 text-white px-4 py-2 rounded-xl font-bold shadow-xl whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity -translate-x-4 group-hover:translate-x-0 pointer-events-none">
            Chat CS AI Piscok Bohay
          </span>
        </div>
      </a>
    </div>
  );
};

export default FloatingAI;
