
import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Instagram, LogIn, UserPlus } from 'lucide-react';
import { COMPANY_INFO } from '../constants';

const Header: React.FC = () => {
  const location = useLocation();
  const isHome = location.pathname === '/';

  const scrollToPortfolio = () => {
    if (isHome) {
      document.getElementById('portfolio')?.scrollIntoView({ behavior: 'smooth' });
    } else {
      window.location.href = '/#portfolio';
    }
  };

  return (
    <header className="sticky top-0 z-50 bg-white/80 backdrop-blur-md shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
        {/* Logo Section */}
        <Link to="/" className="flex items-center space-x-2 group">
          <div className="bg-yellow-400 p-2 rounded-xl group-hover:rotate-12 transition-transform shadow-sm">
            <span className="text-2xl">🍌</span>
          </div>
          <span className="text-2xl font-fredoka font-bold text-amber-900 tracking-tight">Piscok Bohay</span>
        </Link>

        {/* Navigation Section */}
        <nav className="hidden md:flex items-center space-x-8">
          <button 
            onClick={scrollToPortfolio}
            className="text-amber-800 font-semibold hover:text-yellow-600 transition-colors"
          >
            Portofolio
          </button>
          
          <div className="h-6 w-[1px] bg-amber-100"></div>

          <div className="flex items-center space-x-4">
            <Link to="/login" className="flex items-center space-x-1 text-amber-800 hover:text-yellow-600 transition-colors">
              <LogIn size={18} />
              <span className="font-medium">Login</span>
            </Link>
            <Link to="/signup" className="flex items-center space-x-1 bg-yellow-400 text-amber-900 px-4 py-2 rounded-full font-bold hover:bg-yellow-500 transition-all shadow-md active:scale-95">
              <UserPlus size={18} />
              <span>Sign Up</span>
            </Link>
          </div>

          <div className="h-6 w-[1px] bg-amber-100"></div>

          <div className="flex items-center space-x-3">
            <span className="text-sm font-bold text-amber-600 uppercase tracking-widest">Sosial Media</span>
            <a 
              href={COMPANY_INFO.instagram}
              target="_blank" 
              rel="noopener noreferrer"
              className="p-2 bg-gradient-to-tr from-yellow-400 to-pink-500 text-white rounded-lg hover:scale-110 transition-transform shadow-lg"
            >
              <Instagram size={20} />
            </a>
          </div>
        </nav>

        {/* Mobile menu button could be here, but for simplicity we keep basic layout */}
        <div className="md:hidden">
          <a href={COMPANY_INFO.instagram} target="_blank" rel="noopener noreferrer">
             <Instagram size={24} className="text-amber-900" />
          </a>
        </div>
      </div>
    </header>
  );
};

export default Header;
