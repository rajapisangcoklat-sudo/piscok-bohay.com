
import React from 'react';
import { MessageCircle } from 'lucide-react';
import { COMPANY_INFO } from '../constants';

const FloatingWA: React.FC = () => {
  return (
    <a 
      href={`https://wa.me/${COMPANY_INFO.whatsapp}`}
      target="_blank" 
      rel="noopener noreferrer"
      className="fixed bottom-8 right-8 z-[90] group"
    >
      <div className="absolute -inset-4 bg-green-500/20 rounded-full animate-ping opacity-0 group-hover:opacity-100 transition-opacity"></div>
      <div className="relative bg-green-500 text-white p-5 rounded-full shadow-2xl shadow-green-200 flex items-center justify-center transform group-hover:scale-110 group-hover:-rotate-12 transition-all duration-300">
        <MessageCircle size={32} fill="white" />
        <span className="absolute right-full mr-4 bg-white text-green-600 px-4 py-2 rounded-xl font-bold shadow-xl whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity translate-x-4 group-hover:translate-x-0">
          Chat Order Yuk!
        </span>
      </div>
    </a>
  );
};

export default FloatingWA;
