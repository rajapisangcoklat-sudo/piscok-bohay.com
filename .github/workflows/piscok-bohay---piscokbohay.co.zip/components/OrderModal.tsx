
import React, { useState, useEffect } from 'react';
import { X, Plus, Minus, Send, Zap } from 'lucide-react';
import { Product } from '../types';
import { COMPANY_INFO } from '../constants';

interface OrderModalProps {
  product: Product | null;
  isOpen: boolean;
  onClose: () => void;
}

const OrderModal: React.FC<OrderModalProps> = ({ product, isOpen, onClose }) => {
  const [quantity, setQuantity] = useState(1);

  useEffect(() => {
    if (isOpen) setQuantity(1);
  }, [isOpen]);

  if (!product || !isOpen) return null;

  const total = product.price * quantity;

  const handleProceed = () => {
    const message = `Halo Piscok Bohay! 🍌🍫%0A%0ASaya ingin memesan:%0A- Nama Produk: *${product.name}*%0A- Jumlah: *${quantity}*%0A- Total Harga: *Rp${total.toLocaleString('id-ID')}*%0A%0AMohon diproses ya, terima kasih!`;
    window.open(`https://wa.me/${COMPANY_INFO.whatsapp}?text=${message}`, '_blank');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
      <div 
        className="absolute inset-0 bg-amber-900/40 backdrop-blur-sm transition-opacity" 
        onClick={onClose}
      ></div>
      <div className="relative bg-white rounded-3xl w-full max-w-md shadow-2xl overflow-hidden animate-in fade-in zoom-in duration-300">
        {/* Header */}
        <div className="bg-yellow-400 p-6 flex justify-between items-center">
          <h3 className="text-2xl font-fredoka font-bold text-amber-900">Konfirmasi Pesanan</h3>
          <button onClick={onClose} className="p-2 hover:bg-yellow-500 rounded-full transition-colors">
            <X className="text-amber-900" />
          </button>
        </div>

        <div className="p-8 space-y-8">
          {/* Product Detail - Image removed, replaced with Icon */}
          <div className="flex items-center space-x-6 bg-yellow-50 p-6 rounded-3xl">
            <div className="bg-yellow-400 w-16 h-16 rounded-2xl flex items-center justify-center shadow-lg shrink-0">
               <Zap size={32} className="text-amber-900" fill="currentColor" />
            </div>
            <div>
              <h4 className="text-2xl font-bold text-amber-900">{product.name}</h4>
              <p className="text-amber-700 font-bold text-lg">Rp{product.price.toLocaleString('id-ID')}</p>
            </div>
          </div>

          {/* Quantity Selector */}
          <div className="space-y-4">
            <label className="block text-sm font-bold text-amber-800 uppercase tracking-widest text-center">Jumlah Pesanan</label>
            <div className="flex items-center justify-center space-x-10">
              <button 
                onClick={() => setQuantity(prev => Math.max(1, prev - 1))}
                className="p-4 bg-amber-100 text-amber-900 rounded-[1.5rem] hover:bg-amber-200 transition-colors shadow-md active:scale-90"
              >
                <Minus size={28} />
              </button>
              <span className="text-5xl font-fredoka font-bold text-amber-900 min-w-[3.5rem] text-center">{quantity}</span>
              <button 
                onClick={() => setQuantity(prev => prev + 1)}
                className="p-4 bg-amber-900 text-white rounded-[1.5rem] hover:bg-amber-800 transition-colors shadow-lg active:scale-90"
              >
                <Plus size={28} />
              </button>
            </div>
          </div>

          {/* Summary */}
          <div className="pt-6 border-t border-amber-100">
            <div className="flex justify-between items-center mb-8">
              <span className="text-xl font-semibold text-amber-800">Total Pembayaran</span>
              <span className="text-3xl font-fredoka font-bold text-amber-900 bg-yellow-100 px-4 py-1 rounded-xl">Rp{total.toLocaleString('id-ID')}</span>
            </div>
            
            <button 
              onClick={handleProceed}
              className="w-full bg-green-500 hover:bg-green-600 text-white py-5 rounded-[1.5rem] font-bold text-xl flex items-center justify-center space-x-3 shadow-xl shadow-green-200 transition-all active:scale-[0.98] group"
            >
              <Send size={24} className="group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
              <span>Lanjutkan ke WhatsApp</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default OrderModal;
