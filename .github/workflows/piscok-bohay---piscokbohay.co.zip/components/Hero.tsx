
import React from 'react';

const Hero: React.FC = () => {
  return (
    <section className="relative py-16 px-4 flex flex-col items-center justify-center text-center">
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="inline-block px-4 py-1.5 bg-yellow-100 text-yellow-800 rounded-full font-bold text-sm uppercase tracking-widest mb-4">
          Camilan UMKM Favorit Keluarga
        </div>
        <h1 className="text-5xl md:text-7xl font-fredoka font-bold text-amber-900 leading-tight">
          Piscok <span className="text-yellow-500">Bohay</span>: <br /> 
          Gede, Lumer, Juara!
        </h1>
        <p className="text-lg md:text-xl text-amber-800 max-w-2xl mx-auto font-medium">
          Dibuat dari pisang pilihan dengan balutan coklat melimpah. Sekali gigit, lumer di mulut!
        </p>
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4">
          <button 
            onClick={() => document.getElementById('products')?.scrollIntoView({ behavior: 'smooth' })}
            className="w-full sm:w-auto px-8 py-4 bg-amber-900 text-white rounded-2xl font-bold text-lg hover:bg-amber-800 transition-all shadow-xl hover:shadow-2xl active:scale-95"
          >
            Lihat Menu Kami
          </button>
          <button 
             onClick={() => document.getElementById('portfolio')?.scrollIntoView({ behavior: 'smooth' })}
             className="w-full sm:w-auto px-8 py-4 bg-white text-amber-900 border-2 border-amber-900/10 rounded-2xl font-bold text-lg hover:bg-yellow-50 transition-all shadow-md active:scale-95"
          >
            Tentang Kami
          </button>
        </div>
      </div>
      
      {/* Decorative Splash */}
      <div className="absolute bottom-0 left-0 w-full h-24 bg-gradient-to-t from-yellow-50 to-transparent pointer-events-none"></div>
    </section>
  );
};

export default Hero;
