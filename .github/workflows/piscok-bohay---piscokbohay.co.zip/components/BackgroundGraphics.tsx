
import React from 'react';

const BackgroundGraphics: React.FC = () => {
  return (
    <div className="fixed inset-0 pointer-events-none z-[-1] overflow-hidden select-none">
      {/* Soft Gradient Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-yellow-50 via-white to-amber-50/30"></div>

      {/* Dripping Chocolate Drops - Animated */}
      <div className="absolute top-0 left-[5%] w-6 h-64 bg-gradient-to-b from-amber-900 to-transparent rounded-full drip-animation opacity-30" style={{ animationDuration: '10s', animationDelay: '0s' }}></div>
      <div className="absolute top-0 left-[25%] w-8 h-80 bg-gradient-to-b from-amber-800 to-transparent rounded-full drip-animation opacity-20" style={{ animationDuration: '14s', animationDelay: '3s' }}></div>
      <div className="absolute top-0 left-[55%] w-10 h-96 bg-gradient-to-b from-amber-950 to-transparent rounded-full drip-animation opacity-25" style={{ animationDuration: '12s', animationDelay: '1s' }}></div>
      <div className="absolute top-0 left-[85%] w-5 h-72 bg-gradient-to-b from-amber-900 to-transparent rounded-full drip-animation opacity-30" style={{ animationDuration: '16s', animationDelay: '5s' }}></div>

      {/* Floating Animated Bananas */}
      <div className="absolute top-[20%] left-[10%] text-6xl opacity-10 animate-bounce" style={{ animationDuration: '6s' }}>🍌</div>
      <div className="absolute top-[60%] right-[15%] text-7xl opacity-10 animate-pulse" style={{ animationDuration: '8s' }}>🍌</div>
      <div className="absolute bottom-[10%] left-[30%] text-5xl opacity-10 rotate-12">🍌</div>
      <div className="absolute top-[40%] right-[5%] text-6xl opacity-5 -rotate-45">🍌</div>

      {/* Large Decorative Circles */}
      <div className="absolute -top-20 -right-20 w-96 h-96 bg-yellow-200/40 rounded-full blur-[100px]"></div>
      <div className="absolute -bottom-20 -left-20 w-96 h-96 bg-amber-200/20 rounded-full blur-[100px]"></div>
    </div>
  );
};

export default BackgroundGraphics;
