
import React from 'react';
import { ShoppingBag, Star, Zap } from 'lucide-react';
import { PRODUCTS } from '../constants';
import { Product } from '../types';

interface ProductSectionProps {
  onOrder: (product: Product) => void;
}

const ProductSectionComponent: React.FC<ProductSectionProps> = ({ onOrder }) => {
  return (
    <section id="products" className="py-20 px-4 bg-white/40 backdrop-blur-sm">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16 space-y-4">
          <div className="inline-flex items-center space-x-2 bg-amber-100 text-amber-900 px-4 py-1 rounded-full text-sm font-bold uppercase tracking-widest mb-2">
            <Star size={16} fill="currentColor" />
            <span>Best Seller</span>
            <Star size={16} fill="currentColor" />
          </div>
          <h2 className="text-4xl md:text-5xl font-fredoka font-bold text-amber-900">Menu Andalan Kami</h2>
          <p className="text-amber-700 max-w-xl mx-auto font-medium">Piscok jumbo dengan isian lumer yang bikin nagih. Pilih varian favoritmu!</p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          {PRODUCTS.map((product) => (
            <div key={product.id} className="bg-white rounded-[2.5rem] p-10 shadow-xl hover:shadow-yellow-200/50 transition-all duration-500 group flex flex-col border border-amber-50 relative overflow-hidden">
              {/* Background Decoration */}
              <div className="absolute -top-10 -right-10 w-32 h-32 bg-yellow-400/10 rounded-full blur-3xl group-hover:bg-yellow-400/20 transition-colors"></div>
              
              <div className="relative z-10 flex flex-col h-full">
                <div className="flex justify-between items-start mb-6">
                  <div className="space-y-2">
                    <div className="bg-yellow-100 text-yellow-700 w-12 h-12 rounded-2xl flex items-center justify-center mb-4">
                       <Zap size={24} fill="currentColor" />
                    </div>
                    <h3 className="text-3xl font-fredoka font-bold text-amber-900">{product.name}</h3>
                    <div className="flex text-yellow-500">
                      {[...Array(5)].map((_, i) => <Star key={i} size={16} fill="currentColor" />)}
                    </div>
                  </div>
                  <div className="text-right">
                    <span className="block text-xs font-bold text-amber-600 uppercase tracking-widest mb-1">Harga</span>
                    <div className="text-3xl font-fredoka font-bold text-amber-900">
                      Rp{product.price.toLocaleString('id-ID')}
                    </div>
                  </div>
                </div>
                
                <p className="text-amber-800/70 mb-10 leading-relaxed font-medium text-lg">
                  {product.id === 'original' 
                    ? 'Sensasi klasik pisang manis dengan balutan coklat pekat yang meleleh sempurna di setiap gigitan. Ukuran jumbo yang puas!' 
                    : 'Perpaduan mewah rasa coklat dan susu dalam glaze tiramisu yang lembut, memberikan pengalaman rasa yang premium.'}
                </p>

                {/* 4 Photo Indicators (Visual Only as per user style preference) */}
                <div className="flex gap-2 mb-8">
                  {product.images.slice(0, 4).map((_, idx) => (
                    <div key={idx} className="h-1.5 flex-1 bg-amber-100 rounded-full group-hover:bg-yellow-400/30 transition-colors"></div>
                  ))}
                </div>

                <button 
                  onClick={() => onOrder(product)}
                  className="mt-auto w-full flex items-center justify-center space-x-3 bg-yellow-400 hover:bg-yellow-500 text-amber-900 font-extrabold py-5 rounded-2xl transition-all shadow-lg hover:shadow-yellow-400/30 group-hover:translate-y-[-4px] active:scale-95"
                >
                  <ShoppingBag size={22} strokeWidth={2.5} />
                  <span className="text-xl">Pesan Sekarang</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ProductSectionComponent;
