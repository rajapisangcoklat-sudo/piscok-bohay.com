
import React from 'react';
import { HashRouter as Router, Routes, Route } from 'react-router-dom';
import HomePage from './pages/HomePage';
import LoginPage from './pages/LoginPage';
import SignUpPage from './pages/SignUpPage';
import FloatingWA from './components/FloatingWA';
import FloatingAI from './components/FloatingAI';
import Header from './components/Header';
import BackgroundGraphics from './components/BackgroundGraphics';

const App: React.FC = () => {
  return (
    <Router>
      <div className="relative min-h-screen">
        <BackgroundGraphics />
        <Header />
        <main>
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/login" element={<LoginPage />} />
            <Route path="/signup" element={<SignUpPage />} />
          </Routes>
        </main>
        <FloatingAI />
        <FloatingWA />
      </div>
    </Router>
  );
};

export default App;
