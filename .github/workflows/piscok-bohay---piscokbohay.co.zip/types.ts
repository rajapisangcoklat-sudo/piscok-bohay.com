
export interface Product {
  id: string;
  name: string;
  price: number;
  images: string[];
}

export interface OrderState {
  product: Product | null;
  quantity: number;
}
