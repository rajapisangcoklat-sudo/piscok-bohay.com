
import { Product } from './types';

export const PRODUCTS: Product[] = [
  {
    id: 'original',
    name: 'Piscok Bohay Original',
    price: 10000,
    images: [
      'https://images.unsplash.com/photo-1563805042-7684c019e1cb?q=80&w=800&auto=format&fit=crop', // Appetizing chocolate dessert
      'https://images.unsplash.com/photo-1603532648955-0393e01c8f62?q=80&w=800&auto=format&fit=crop', // Melting chocolate close-up
      'https://images.unsplash.com/photo-1511914265872-c40672604a80?q=80&w=800&auto=format&fit=crop', // Golden fried texture vibes
      'https://images.unsplash.com/photo-1551024506-0bccd828d307?q=80&w=800&auto=format&fit=crop'  // Deep chocolate sauce
    ]
  },
  {
    id: 'tiramishu',
    name: 'Piscok Bohay Tiramishu',
    price: 12000,
    images: [
      'https://images.unsplash.com/photo-1571877227200-a0d98ea607e9?q=80&w=800&auto=format&fit=crop', // Tiramisu creaminess
      'https://images.unsplash.com/photo-1542124948-dc391252a940?q=80&w=800&auto=format&fit=crop', // Coffee and cream dessert
      'https://images.unsplash.com/photo-1464195244916-405fa0a82545?q=80&w=800&auto=format&fit=crop', // Dusting of cocoa
      'https://images.unsplash.com/photo-1558961363-fa8fdf82db35?q=80&w=800&auto=format&fit=crop'  // Gourmet sweet platter
    ]
  }
];

export const COMPANY_INFO = {
  since: '19 Desember 2025',
  owner: 'Satrio Wibowo',
  producer: 'Tim Piscok Bohay Entertainment',
  whatsapp: '6285719495137',
  instagram: 'https://www.instagram.com/piscok_bohay26/'
};
