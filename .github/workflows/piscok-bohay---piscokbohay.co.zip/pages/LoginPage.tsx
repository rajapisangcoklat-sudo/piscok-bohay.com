import React from 'react';
import { Link } from 'react-router-dom';
import { Mail, Lock, ArrowRight } from 'lucide-react';

const LoginPage: React.FC = () => {
  return (
    <div className="min-h-[calc(100vh-80px)] flex items-center justify-center p-6 bg-yellow-50 relative overflow-hidden">
      {/* Dynamic Background elements */}
      <div className="absolute top-[-10%] right-[-10%] w-[400px] h-[400px] bg-yellow-200/40 rounded-full blur-[120px] animate-pulse"></div>
      <div className="absolute bottom-[-10%] left-[-10%] w-[400px] h-[400px] bg-amber-200/30 rounded-full blur-[120px] animate-pulse delay-1000"></div>

      <div className="bg-white rounded-[3.5rem] shadow-2xl w-full max-w-lg overflow-hidden relative border border-yellow-100 z-10 transition-transform hover:scale-[1.01] duration-500">
        <div className="p-12 md:p-16 relative">
          <div className="text-center mb-12 space-y-4">
            <div className="bg-yellow-400 w-20 h-20 rounded-[2rem] flex items-center justify-center mx-auto mb-8 shadow-xl shadow-yellow-200 animate-bounce transition-all">
              <span className="text-4xl">🍌</span>
            </div>
            <h1 className="text-4xl font-fredoka font-bold text-amber-900 tracking-tight">Login All Account</h1>
            <p className="text-amber-700 font-semibold text-lg">Nikmati kelezatan Piscok Bohay setiap saat!</p>
          </div>

          <form className="space-y-7" onSubmit={(e) => e.preventDefault()}>
            <div className="space-y-3">
              <label className="text-xs font-bold text-amber-800 uppercase tracking-widest ml-2">Email Address</label>
              <div className="relative group">
                <Mail className="absolute left-5 top-1/2 -translate-y-1/2 text-amber-400 group-focus-within:text-yellow-500 transition-colors" size={22} />
                <input 
                  type="email" 
                  placeholder="admin@piscokbohay.co" 
                  className="w-full bg-yellow-50/40 border-2 border-amber-50 rounded-[1.5rem] py-5 pl-14 pr-6 focus:outline-none focus:border-yellow-400 focus:ring-8 focus:ring-yellow-400/5 transition-all font-semibold text-amber-900 placeholder:text-amber-200"
                />
              </div>
            </div>

            <div className="space-y-3">
              <label className="text-xs font-bold text-amber-800 uppercase tracking-widest ml-2">Password</label>
              <div className="relative group">
                <Lock className="absolute left-5 top-1/2 -translate-y-1/2 text-amber-400 group-focus-within:text-yellow-500 transition-colors" size={22} />
                <input 
                  type="password" 
                  placeholder="••••••••" 
                  className="w-full bg-yellow-50/40 border-2 border-amber-50 rounded-[1.5rem] py-5 pl-14 pr-6 focus:outline-none focus:border-yellow-400 focus:ring-8 focus:ring-yellow-400/5 transition-all font-semibold text-amber-900 placeholder:text-amber-200"
                />
              </div>
            </div>

            <div className="flex items-center justify-end">
              <button type="button" className="text-sm font-bold text-yellow-600 hover:text-yellow-700 transition-colors hover:underline">
                Lupa Password?
              </button>
            </div>

            <button 
              type="submit" 
              className="w-full bg-amber-900 hover:bg-amber-800 text-white py-5 rounded-[1.5rem] font-bold text-xl flex items-center justify-center space-x-3 shadow-2xl shadow-amber-900/30 transition-all active:scale-[0.97] group"
            >
              <span>Masuk Akun</span>
              <ArrowRight size={24} className="group-hover:translate-x-1 transition-transform" />
            </button>
          </form>

          <div className="mt-12 pt-10 border-t border-amber-50 text-center">
            <p className="text-amber-800 font-medium text-lg">
              Belum punya akun? {' '}
              <Link to="/signup" className="text-yellow-600 font-extrabold hover:text-yellow-700 transition-colors underline decoration-yellow-200 decoration-4 underline-offset-4">Daftar Sekarang</Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;