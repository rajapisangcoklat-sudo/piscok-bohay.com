
import React, { useState } from 'react';
import Hero from '../components/Hero';
import ProductSection from '../components/ProductSection';
import Portfolio from '../components/Portfolio';
import OrderModal from '../components/OrderModal';
import { Product } from '../types';

const HomePage: React.FC = () => {
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);

  return (
    <div className="pb-20">
      <Hero />
      <ProductSection onOrder={setSelectedProduct} />
      <Portfolio />
      
      <OrderModal 
        product={selectedProduct} 
        isOpen={!!selectedProduct} 
        onClose={() => setSelectedProduct(null)} 
      />

      <footer className="text-center py-16 text-amber-800/60 font-medium">
        <div className="flex items-center justify-center space-x-2 mb-4">
          <div className="h-[1px] w-8 bg-amber-200"></div>
          <span className="text-xs font-bold uppercase tracking-[0.3em]">Official Website</span>
          <div className="h-[1px] w-8 bg-amber-200"></div>
        </div>
        <p className="text-lg font-bold text-amber-900/40 mb-2">piscokbohay.co</p>
        <p>&copy; 2025 Piscok Bohay Entertainment. Semua Hak Dilindungi.</p>
        <p className="text-sm mt-2">Dibuat dengan ❤️ untuk UMKM Indonesia</p>
      </footer>
    </div>
  );
};

export default HomePage;
