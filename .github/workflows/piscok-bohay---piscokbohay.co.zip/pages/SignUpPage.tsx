import React from 'react';
import { Link } from 'react-router-dom';
import { User, Mail, Lock, ArrowRight } from 'lucide-react';

const SignUpPage: React.FC = () => {
  return (
    <div className="min-h-[calc(100vh-80px)] flex items-center justify-center p-6 bg-yellow-50 relative overflow-hidden">
      {/* Background blobs */}
      <div className="absolute top-0 left-0 w-80 h-80 bg-amber-100 rounded-full blur-[80px] -translate-x-1/2 -translate-y-1/2"></div>
      <div className="absolute bottom-0 right-0 w-80 h-80 bg-yellow-200 rounded-full blur-[80px] translate-x-1/2 translate-y-1/2"></div>

      <div className="bg-white rounded-[3.5rem] shadow-2xl w-full max-w-lg overflow-hidden relative border border-yellow-100 z-10 transition-transform hover:scale-[1.01] duration-500">
        <div className="p-12 md:p-16 relative">
          <div className="text-center mb-12 space-y-4">
            <div className="bg-amber-100 w-20 h-20 rounded-[2rem] flex items-center justify-center mx-auto mb-8 shadow-xl shadow-amber-50">
              <span className="text-4xl">🍫</span>
            </div>
            <h1 className="text-4xl font-fredoka font-bold text-amber-900 tracking-tight">Gabung Sobat Bohay</h1>
            <p className="text-amber-700 font-semibold text-lg">Nikmati promo spesial khusus member!</p>
          </div>

          <form className="space-y-7" onSubmit={(e) => e.preventDefault()}>
             <div className="space-y-3">
              <label className="text-xs font-bold text-amber-800 uppercase tracking-widest ml-2">Nama Lengkap</label>
              <div className="relative group">
                <User className="absolute left-5 top-1/2 -translate-y-1/2 text-amber-400 group-focus-within:text-yellow-500 transition-colors" size={22} />
                <input 
                  type="text" 
                  placeholder="Nama Lengkap Anda" 
                  className="w-full bg-yellow-50/40 border-2 border-amber-50 rounded-[1.5rem] py-5 pl-14 pr-6 focus:outline-none focus:border-yellow-400 focus:ring-8 focus:ring-yellow-400/5 transition-all font-semibold text-amber-900 placeholder:text-amber-200"
                />
              </div>
            </div>

            <div className="space-y-3">
              <label className="text-xs font-bold text-amber-800 uppercase tracking-widest ml-2">Email Address</label>
              <div className="relative group">
                <Mail className="absolute left-5 top-1/2 -translate-y-1/2 text-amber-400 group-focus-within:text-yellow-500 transition-colors" size={22} />
                <input 
                  type="email" 
                  placeholder="anda@piscokbohay.co" 
                  className="w-full bg-yellow-50/40 border-2 border-amber-50 rounded-[1.5rem] py-5 pl-14 pr-6 focus:outline-none focus:border-yellow-400 focus:ring-8 focus:ring-yellow-400/5 transition-all font-semibold text-amber-900 placeholder:text-amber-200"
                />
              </div>
            </div>

            <div className="space-y-3">
              <label className="text-xs font-bold text-amber-800 uppercase tracking-widest ml-2">Password</label>
              <div className="relative group">
                <Lock className="absolute left-5 top-1/2 -translate-y-1/2 text-amber-400 group-focus-within:text-yellow-500 transition-colors" size={22} />
                <input 
                  type="password" 
                  placeholder="••••••••" 
                  className="w-full bg-yellow-50/40 border-2 border-amber-50 rounded-[1.5rem] py-5 pl-14 pr-6 focus:outline-none focus:border-yellow-400 focus:ring-8 focus:ring-yellow-400/5 transition-all font-semibold text-amber-900 placeholder:text-amber-200"
                />
              </div>
            </div>

            <button 
              type="submit" 
              className="w-full bg-yellow-400 hover:bg-yellow-500 text-amber-900 py-5 rounded-[1.5rem] font-bold text-xl flex items-center justify-center space-x-3 shadow-2xl shadow-yellow-400/30 transition-all active:scale-[0.97] group"
            >
              <span>Daftar Akun</span>
              <ArrowRight size={24} className="group-hover:translate-x-1 transition-transform" />
            </button>
          </form>

          <div className="mt-12 pt-10 border-t border-amber-50 text-center">
            <p className="text-amber-800 font-medium text-lg">
              Sudah punya akun? {' '}
              <Link to="/login" className="text-amber-900 font-extrabold hover:text-yellow-700 transition-colors underline decoration-yellow-200 decoration-4 underline-offset-4">Login di sini</Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SignUpPage;